package br.com.fiap.jpa.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "t_gco_condominio")
@SequenceGenerator(name = "condominio", sequenceName = "sq_t_gco_condominio", allocationSize = 1)
public class Condominio implements Serializable {
	
	private static final long serialVersionUID = 496363751778298271L;
	
	public Condominio() {
		
	}
	
	public Condominio(int cnpj, String razaoSocial, String nomeFantasia, LocalDate dataFundacao) {
		this.cnpj = cnpj;
		this.razao_social = razaoSocial;
		this.nome_fantasia =  nomeFantasia;
		this.data_fundacao = dataFundacao;
	}

	@Id
	@Column(name = "id_condominio")
	@GeneratedValue(generator = "condominio", strategy = GenerationType.SEQUENCE)
	private Long id;
	
	@Column(name = "nr_cnpj", nullable = false)
	private int cnpj;
	
	@Column(name = "ds_razao_social", length = 30, nullable = false)
	private String razao_social;
	
	@Column(name = "nm_fantasia", length = 20, nullable = false)
	private String nome_fantasia;
	
	@Column(name = "dt_fundacao", nullable = false)
	private LocalDate data_fundacao;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public int getCnpj() {
		return cnpj;
	}

	public void setCnpj(int cnpj) {
		this.cnpj = cnpj;
	}

	public String getRazao_social() {
		return razao_social;
	}

	public void setRazao_social(String razao_social) {
		this.razao_social = razao_social;
	}

	public String getNome_fantasia() {
		return nome_fantasia;
	}

	public void setNome_fantasia(String nome_fantasia) {
		this.nome_fantasia = nome_fantasia;
	}

	public LocalDate getData_fundacao() {
		return data_fundacao;
	}

	public void setData_fundacao(LocalDate data_fundacao) {
		this.data_fundacao = data_fundacao;
	}

	@Override
	public String toString() {
		return "\nCNPJ: " + this.getCnpj()
		+ "\nRazaoSocial: " + this.getRazao_social()
		+ "\nNome: " + this.getNome_fantasia()
		+ "\nData: " + this.getData_fundacao().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
	}

}
