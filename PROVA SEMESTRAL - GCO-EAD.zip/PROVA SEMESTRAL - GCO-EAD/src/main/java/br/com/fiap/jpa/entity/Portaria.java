package br.com.fiap.jpa.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "t_gco_portaria")
@SequenceGenerator(name = "portaria", sequenceName = "sq_t_gco_portaria", allocationSize = 1)
public class Portaria implements Serializable {
	
	private static final long serialVersionUID = -4156730017576618081L;
	
	public Portaria() {
		
	}
	
	public Portaria(int numero, String nome, String status, LocalDate dt_inicio, LocalDate dt_termino, Condominio condominio) {
		this.numero_portaria = numero;
		this.nome_portaria = nome;
		this.status = status;
		this.data_inicio = dt_inicio;
		this.data_termino = dt_termino;
		this.condominio = condominio;
	}

	@Id
	@Column(name = "id_portaria")
	@GeneratedValue(generator = "portaria", strategy = GenerationType.SEQUENCE)
	private Long id;
	
	@Column(name = "nr_portaria", nullable = false)
	private int numero_portaria;
	
	@Column(name = "nm_portaria", length = 20, nullable = false)
	private String nome_portaria;
	
	@Column(name = "ds_status", length = 50, nullable = false)
	private String status;
	
	@Column(name = "dt_inicio", nullable = false)
	private LocalDate data_inicio;
	
	@Column(name = "dt_termino", nullable = false)
	private LocalDate data_termino;
	
	@ManyToOne
	@JoinColumn(name = "id_condominio")
	private Condominio condominio;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public int getNumero_portaria() {
		return numero_portaria;
	}

	public void setNumero_portaria(int numero_portaria) {
		this.numero_portaria = numero_portaria;
	}

	public String getNome_portaria() {
		return nome_portaria;
	}

	public void setNome_portaria(String nome_portaria) {
		this.nome_portaria = nome_portaria;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getData_inicio() {
		return data_inicio;
	}

	public void setData_inicio(LocalDate data_inicio) {
		this.data_inicio = data_inicio;
	}

	public LocalDate getData_termino() {
		return data_termino;
	}

	public void setData_termino(LocalDate data_termino) {
		this.data_termino = data_termino;
	}

	public Condominio getCondominio() {
		return condominio;
	}

	public void setCondominio(Condominio condominio) {
		this.condominio = condominio;
	}

	@Override
	public String toString() {
		return "\nNumero: " + this.getNumero_portaria()
			+ "\nNome: " + this.getNome_portaria()
			+ "\nStatus: " + this.getStatus()
			+ "\nDataInicio: " + this.getData_inicio().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
			+ "\nDataT�rmino: " + this.getData_termino().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
			+ "\nEvento: " + this.getCondominio().getNome_fantasia();
	}

}
