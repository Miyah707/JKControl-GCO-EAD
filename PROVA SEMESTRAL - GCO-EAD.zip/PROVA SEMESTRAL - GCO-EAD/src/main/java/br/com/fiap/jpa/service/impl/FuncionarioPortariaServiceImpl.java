package br.com.fiap.jpa.service.impl;

import java.time.LocalDate;
import java.util.List;

import br.com.fiap.jpa.dao.impl.FuncionarioPortariaDAOImpl;
import br.com.fiap.jpa.entity.FuncionarioPortaria;
import br.com.fiap.jpa.service.GenericService;

public class FuncionarioPortariaServiceImpl extends GenericService<FuncionarioPortaria, Long> {
	
	private static FuncionarioPortariaServiceImpl instance = null;
	
	private FuncionarioPortariaDAOImpl participanteDAO;
	
	private FuncionarioPortariaServiceImpl() {
		this.participanteDAO = FuncionarioPortariaDAOImpl.getInstance();
	}
	
	public static FuncionarioPortariaServiceImpl getInstance() {
		
		if (instance == null) {
			instance = new FuncionarioPortariaServiceImpl();
		}
		
		return instance;
	}

	@Override
	public void inserir(FuncionarioPortaria instance) {
		
	}

	@Override
	public void atualizar(FuncionarioPortaria instance) {
		
	}

	@Override
	public void remover(Long id) {
		
	}

	@Override
	
	public FuncionarioPortaria obter(Long id) {
		FuncionarioPortaria func = null;
		
		try {
			func = participanteDAO.obterPorId(id, getEntityManager());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}
		
		return func;
	}

	@Override
	public List<FuncionarioPortaria> listar() {
		return null;
	}
	
	public List<FuncionarioPortaria> pesquisar(String nome, String cpf, LocalDate dataCadastro) {
		List<FuncionarioPortaria> funcs = null;
		
		try {
			funcs = participanteDAO.pesquisar(nome, cpf, dataCadastro, getEntityManager());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}
		
		return funcs;
	}

}
