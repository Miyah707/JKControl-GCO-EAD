package br.com.fiap.jpa.service.impl;

import java.util.List;

import br.com.fiap.jpa.dao.impl.MovimentacaoEntradaDAOImpl;
import br.com.fiap.jpa.entity.MovimentacaoPortaria;
import br.com.fiap.jpa.service.GenericService;

public class MovimentacaoPortariaServiceImpl extends GenericService<MovimentacaoPortaria, Long> {

	private static MovimentacaoPortariaServiceImpl instance = null;
	
	private MovimentacaoEntradaDAOImpl movimentacaoEntradaDAO;
	
	private MovimentacaoPortariaServiceImpl() {
		this.movimentacaoEntradaDAO = MovimentacaoEntradaDAOImpl.getInstance();
	}
	
	public static MovimentacaoPortariaServiceImpl getInstance() {
		
		if (instance == null) {
			instance = new MovimentacaoPortariaServiceImpl();
		}
		
		return instance;
	}
	
	@Override
	public void inserir(MovimentacaoPortaria instance) {
		try {
			movimentacaoEntradaDAO.salvar(instance, getEntityManager());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}
		
	}

	@Override
	public void atualizar(MovimentacaoPortaria instance) {
		
	}

	@Override
	public void remover(Long id) {
		
	}

	@Override
	public MovimentacaoPortaria obter(Long id) {
		return null;
	}

	@Override
	public List<MovimentacaoPortaria> listar() {
		return null;
	}
	
	public List<MovimentacaoPortaria> listarTipo(String tipo) {
		List<MovimentacaoPortaria> movimentacoes = null;
		
		try {
			movimentacoes = movimentacaoEntradaDAO.listarPorTipo(tipo, getEntityManager());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeEntityManager();
		}
		
		return movimentacoes;
	}

}
