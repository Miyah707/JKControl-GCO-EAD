package br.com.fiap.jpa;

import java.time.LocalDate;
import java.time.LocalDateTime;

import br.com.fiap.jpa.entity.Condominio;
import br.com.fiap.jpa.entity.FuncionarioPortaria;
import br.com.fiap.jpa.entity.MovimentacaoPortaria;
import br.com.fiap.jpa.entity.Portaria;
import br.com.fiap.jpa.entity.Visitante;
import br.com.fiap.jpa.service.impl.PortariaServiceImpl;
import br.com.fiap.jpa.service.impl.CondominioServiceImpl;
import br.com.fiap.jpa.service.impl.FuncionarioPortariaServiceImpl;
import br.com.fiap.jpa.service.impl.MovimentacaoPortariaServiceImpl;
import br.com.fiap.jpa.service.impl.VisitanteServiceImpl;

public class App {

	public static void main(String[] args) {
		
		CondominioServiceImpl condominioService = CondominioServiceImpl.getInstance();
		PortariaServiceImpl portariaService = PortariaServiceImpl.getInstance();
		VisitanteServiceImpl participanteService = VisitanteServiceImpl.getInstance();
		MovimentacaoPortariaServiceImpl movimentacaoEntradaService 
				= MovimentacaoPortariaServiceImpl.getInstance();
		FuncionarioPortariaServiceImpl funcionarioService = FuncionarioPortariaServiceImpl.getInstance();
		
		
		
		Condominio condominio = new Condominio(123456789,"Empresa","Cond.Flores", LocalDate.of(2022, 06, 30));
		
		condominioService.inserir(condominio);


		
		Portaria portaria1 = new Portaria(1, "Principal", null, null, null, condominio);
		Portaria portaria2 = new Portaria(2, "Servi�o", null, null, null, condominio);
		
		portariaService.inserir(portaria1);
		portariaService.inserir(portaria2);
		
		
		Visitante participante1 = participanteService.obter(1L);
		Visitante participante2 = participanteService.obter(2L);
		
		FuncionarioPortaria funcionario1 = funcionarioService.obter(1L);
		FuncionarioPortaria funcionario2 = funcionarioService.obter(2L);

		MovimentacaoPortaria movimentacao1 = new MovimentacaoPortaria(LocalDateTime.of(2022,  6, 1, 15, 0, 0), "E", funcionario1, portaria1, participante1);
		MovimentacaoPortaria movimentacao2 = new MovimentacaoPortaria(LocalDateTime.of(2022,  6, 1, 15, 30, 0), "E", funcionario1, portaria1, participante2);
		MovimentacaoPortaria movimentacao3 = new MovimentacaoPortaria(LocalDateTime.of(2022,  6, 1, 15, 45, 0), "S", funcionario2, portaria1, participante1);
		
		movimentacaoEntradaService.inserir(movimentacao1);
		movimentacaoEntradaService.inserir(movimentacao2);
		movimentacaoEntradaService.inserir(movimentacao3);
		

		movimentacaoEntradaService.listarTipo("E").forEach(System.out::println);
		movimentacaoEntradaService.listarTipo("S").forEach(System.out::println);
		
		
		participanteService.pesquisar("Jo�o", null, null).forEach(System.out::println);
		participanteService.pesquisar("j", "111.111.111-11", null).forEach(System.out::println);
		participanteService.pesquisar("j", "111.111.111-11", LocalDate.of(2022, 05, 23)).forEach(System.out::println);
	}
}
